import { config } from 'dotenv';
config();

import '@/ai/flows/waste-disposal-assistant.ts';
import '@/ai/flows/wasteiq-assistant.ts';
