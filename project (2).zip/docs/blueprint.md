# **App Name**: WasteIQ – Smarter Waste. Cleaner Cities.

## Core Features:

- Role-Based User Management: Secure login and registration for citizens, alongside dedicated worker authentication, ensuring appropriate access levels based on user roles.
- Dynamic Dashboards: Personalized dashboards for citizens and workers, providing an at-a-glance view of key statistics, alerts, and quick action buttons tailored to their roles.
- AI Waste Disposal Guide: An intelligent tool allowing users to search waste types and receive precise disposal instructions, category, suitable bin, and helpful tips, drawing from a database of 50+ waste examples.
- Issue Reporting & Task Workflow: Empower citizens to report waste issues with photo and location. Workers can access, view details, and update the status of assigned complaints and tasks.
- Smart Bin & Map Visualization: Display real-time fill levels, waste type, and location of smart bins. Integrates map view to show user location, smart bins, recycling centers, and optimized collection routes for workers.
- Citizen Reward & Gamification: Engage citizens through a reward system that tracks recycling points, awards achievement badges, and features a public leaderboard to promote eco-friendly behavior.
- In-App Notifications: Provide timely alerts for citizens regarding bin status, complaint resolution, and reward achievements, and notify workers of new assigned tasks.

## Style Guidelines:

- Primary color: A vibrant, fresh green (#36B858) representing eco-friendliness and clean environments. It ensures visibility against a light background.
- Background color: A subtle, light green-tinted white (#ECF6EF), providing a clean and refreshing canvas for content while maintaining the green theme.
- Accent color: A lively yellow-green (#B7E630), analogous to the primary color but with increased saturation, used for calls to action and important highlights to create contrast.
- Headline and Body Text Font: 'Inter' (sans-serif), chosen for its modern, clean, and highly readable aesthetic, suitable for all text lengths and fostering a straightforward user experience.
- Use simple, clean, and modern line-based icons that are universally recognizable and support the eco-friendly theme without visual clutter.
- Utilize a card-based dashboard layout with rounded UI components for a contemporary, friendly feel, ensuring a simple, organized, and easily navigable interface.
- Implement subtle and smooth transition animations throughout the application, enhancing navigation fluidity and contributing to a polished, modern user experience.