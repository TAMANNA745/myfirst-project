export const firebaseConfig = {
  "projectId": "studio-3682030783-229e2",
  "appId": "1:291092971860:web:c7c09c3196edd612c208c1",
  "apiKey": "AIzaSyC4ZHwN2mE6F2ayDKY814EIyK3d2tsoIsg",
  "authDomain": "studio-3682030783-229e2.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "291092971860"
};
